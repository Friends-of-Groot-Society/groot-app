Thanks for downloading jOOQ.
Please visit http://www.jooq.org for more information.

To install and run this example, simply check it out and run the following Maven command

```
$ pwd
/path/to/checkout/dir
$ cd jOOQ-examples/jOOQ-flyway-ddl-example
...
$ mvn clean install
```

This example uses Flyway and jOOQ's `DDLDatabase` which emulates Flyway's
file ordering.